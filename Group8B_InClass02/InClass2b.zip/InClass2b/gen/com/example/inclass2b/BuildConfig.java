/** Automatically generated file. DO NOT MODIFY */
package com.example.inclass2b;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}